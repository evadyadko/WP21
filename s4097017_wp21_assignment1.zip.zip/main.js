function title() {
    let path = window.location.pathname;
    let page = path.split("/").pop();
    if (page === 'index.html') {
        document.title = 'Webprogramming (LIX018P05) - Index'
    }
    else {
        document.title = 'Webprogramming (LIX018P05) - Second'
}}

function article() {
    let path = window.location.pathname;
    let page = path.split("/").pop();
    if (page === 'index.html') {
        let title = document.createTextNode('Test article title');
        let h1 = document.createElement('h1');
        let para = document.createTextNode('Test article paragraph');
        let p = document.createElement('p');
        let article = document.createElement('article')
        h1.appendChild(title);
        p.appendChild(para);
        article.appendChild(h1);
        article.append(p);
        document.getElementsByClassName('col-md-12')[0].appendChild(article)
    }
}
function hrefLink() {
    let ul = document.getElementById('links');
    let li = ul.getElementsByTagName('li')[2];
    let a = li.childNodes[0];
    a.setAttribute('href', 'http://google.com');
    a.setAttribute('target', '_blank')
}

function rednav() {
    let nav = document.getElementsByClassName('nav-item');
    for (let n=0, max=nav.length; n < max; n++) {
        let item = nav[n].children[0];
        item.style.color = 'red';
    }
}

window.addEventListener('DOMContentLoaded', function(){
    title()
    rednav();
    article();
    hrefLink();
});