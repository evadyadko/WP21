function formValidation(link){
    return !(link.link_name === "" || link.url === "");
}

function add_item(link){
    $("ul#links").append('<li class="site" id="url_add"><a href="' + link.url + '">' + link.link_name + '</a></li>' );
}

$(function(){
    $('button#fade').on('click',function() {
        $('ul#links').toggle('slow');
    });
    $('button#url_add').on('click',function(){
        var link = {
            link_name : $('#input_link_name').val(),
            url : $('#url').val()
        };
        if (formValidation(link) === false){
            $('div#form-alert').show();
        }
        else{
            $('div#form-alert').hide();
            add_item(link);
        }
    });

});