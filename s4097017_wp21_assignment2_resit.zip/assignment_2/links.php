<?php
/* Header */
$page_title = 'Webprogramming Assignment 2';
$navigation = Array(
    'active' => 'Links',
    'items' => Array(
        'Home' => '/WP21/assignment_2/index.php',
        'Links' => '/WP21/assignment_2/links.php',
        'News' => '/WP21/assignment_2/news.php',
        'Future' => '/WP21/assignment_2/future.php'
    )
);
include __DIR__ . '/tpl/head.php';
/* Body */
include __DIR__ . '/tpl/body-start.php';
?>
<script src="js/links.js"></script>
<div class="col-md-12">
    <h1>This is the link page!</h1>
</div>
<div>
    <ul id="links">
        <li class="site">
            <a href="https://youtube.com" target="_blank">Youtube</a>
        </li>
        <li class="site">
            <a href="https://google.com" target="_blank">Google</a>
        </li>
        <li class="site">
            <a href="https://nestor.rug.nl/" target="_blank">Nestor</a>
        </li>
        <li class="site">
            <a href="https://facebook.com" target="_blank">Facebook</a>
        </li>
    </ul>
    <div class="alert alert-danger" id="form-alert" role="alert">
        Not all form fields are filled in correctly!
    </div>
    <form>
        <div class="form">
            <label for="input_link_name">Link name</label>
            <input type="text" class="form-control" id="input_link_name" placeholder="Enter link name">
        </div>
        <div class="form">
            <label for="url">URL</label>
            <input type="url" class="form-control" id="url" placeholder="Enter your url!">
        </div>
        <button type="button" id="url_add">Add your url</button>
    </form>
    <button type="button" id="remove">Remove</button>
    <button type="button" id="fade">Fade or show</button>
</div>
<?php
include __DIR__ . '/tpl/body-end.php';
/* Footer */
include __DIR__ . '/tpl/footer.php'; ?>
