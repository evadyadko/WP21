<?php
/* Header */
$page_title = 'Webprogramming Assignment 3';
$navigation = Array(
    'active' => 'Simple Form',
    'items' => Array(
        'News' => '/WP21/assignment_3/index.php',
        'Add news item' => '/WP21/assignment_3/news_add.php',
        'Leap Year' => '/WP21/assignment_3/leapyear.php',
        'Simple Form' => '/WP21/assignment_3/simple_form.php'
    )
);
include __DIR__ . '/tpl/head.php';
include __DIR__ . '/tpl/body_start.php';
?>

<?php
include __DIR__ . '/tpl/body_end.php';
?>

<?php
$nameErr = $placeErr = "";
$name = $place = "";

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (empty($_GET["name"])) {
        $nameErr = "Name is required";
    } else {
        $name = test_input($_GET["name"]);
        if (!preg_match("/^[a-zA-Z-' ]*$/", $name)) {
            $nameErr = "Only letters and white space allowed";
        }
    }

    if (empty($_GET["place"])) {
        $placeErr = "Place is required";
    } else {
        $place = test_input($_GET["place"]);
        }

}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php
                echo "<h1>Welcome $name !</h1>";
                if ($place == "Amsterdam") {
                    echo "You're from the capital of the Netherlands!";
                } else {
                    echo "You're from $place !";
                }
                ?>
                <form method="GET" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                    Name: <input type="text" name="name" value="<?php echo $name;?>">
                    <span class="error">* <?php echo $nameErr;?></span>
                    <br><br>
                    Place: <input type="text" name="place" value="<?php echo $place;?>">
                    <span class="error">* <?php echo $placeErr;?></span>
                    <br><br>
                    <input type="submit" name="submit" value="Submit">
                </form>
            </div>
        </div>
    </div>
</body>
</html>
